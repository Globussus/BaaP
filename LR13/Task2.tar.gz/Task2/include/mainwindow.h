#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QTextEdit>

#include "string.h"

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

    void updateDisplay();

private slots:
    void stringClicked();

private:
    String string;
    QPushButton* stringButton;
    QTextEdit* textEdit;
};

#endif 