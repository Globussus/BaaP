#ifndef CIRCLE_H
#define CIRCLE_H

#include "shape.h"
#include <QtMath>

class Circle : public Shape {
    Q_OBJECT
public:
    explicit Circle(QPointF center, double radius, QObject *parent = nullptr);

    double area() const override;
    double perimeter() const override;
    QPointF centerOfMass() const override;

    void setCenterOfMass(const QPointF& newCenter) override;

    void move(const QPointF& delta) override;
    void rotate(double angleDegrees, const QPointF& pivot) override;
    void scale(double factor, const QPointF& pivot) override;

    void draw(QPainter* painter) const override;
    bool contains(const QPointF& point) const override;

    double getRadius() const { return r; }
    void setRadius(double newR);

private:
    QPointF center;
    double r;
};

#endif
