#include "octagon.h"
#include <QtMath>

Octagon::Octagon(const QPointF& center, double radius, QObject *parent)
    : Polygon(parent), r(radius)
{
    updateVertices(center);
}

void Octagon::setRadius(double radius) {
    QPointF currentCenter = centerOfMass();
    r = qMax(0.0, radius);
    updateVertices(currentCenter);
}

void Octagon::updateVertices(const QPointF& center) {
    vertices.clear();
    for (int i = 0; i < 8; ++i) {
        double angle = qDegreesToRadians(i * 45.0 + 22.5);
        double x = center.x() + r * qCos(angle);
        double y = center.y() + r * qSin(angle);
        vertices << QPointF(x, y);
    }

    emit shapeChanged();
}
