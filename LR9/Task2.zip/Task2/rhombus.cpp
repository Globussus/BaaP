#include "rhombus.h"

Rhombus::Rhombus(const QPointF& center, double d1, double d2, QObject *parent)
    : Polygon(parent), diag1(d1), diag2(d2)
{
    updateVertices(center);
}

void Rhombus::setDiagonals(double d1, double d2) {
    QPointF currentCenter = centerOfMass();
    diag1 = qMax(0.0, d1);
    diag2 = qMax(0.0, d2);
    updateVertices(currentCenter);
}

void Rhombus::updateVertices(const QPointF& center) {
    double h1 = diag1 / 2.0;
    double h2 = diag2 / 2.0;

    vertices.clear();

    vertices << QPointF(center.x(), center.y() - h2); // Верх
    vertices << QPointF(center.x() + h1, center.y()); // Право
    vertices << QPointF(center.x(), center.y() + h2); // Низ
    vertices << QPointF(center.x() - h1, center.y()); // Лево

    emit shapeChanged();
}
