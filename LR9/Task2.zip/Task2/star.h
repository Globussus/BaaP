#ifndef STAR_H
#define STAR_H

#include "polygon.h"

class Star : public Polygon {
    Q_OBJECT
public:
    Star(const QPointF& center, int rays, double outerR, double innerR, QObject *parent = nullptr);

    void setParameters(int rays, double outerR, double innerR);

    int getRays() const { return numRays; }
    double getOuterR() const { return rOuter; }
    double getInnerR() const { return rInner; }

private:
    void updateVertices(const QPointF& center);
    int numRays;
    double rOuter;
    double rInner;
};
#endif
