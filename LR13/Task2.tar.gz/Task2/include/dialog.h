#ifndef DIALOG_H
#define DIALOG_H

#include <QComboBox>
#include <QDialog>
#include <QGridLayout>
#include <QInputDialog>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>

#include "mainwindow.h"
#include "string"

class Dialog : public QDialog {
    Q_OBJECT

public:
    explicit Dialog(MainWindow* window, String* string,
                    QDialog* next = nullptr, QWidget* parent = nullptr);
    ~Dialog();

private slots:
    void call();

private:
    MainWindow* window;
    String* string;
    QComboBox* box;
    QPushButton* callButton;

    char getCharacter();
    String getString();
};

#endif