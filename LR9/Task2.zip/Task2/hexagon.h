#ifndef HEXAGON_H
#define HEXAGON_H

#include "polygon.h"

class Hexagon : public Polygon {
    Q_OBJECT
public:
    Hexagon(const QPointF& center, double radius, QObject *parent = nullptr);

    void setRadius(double radius);

private:
    void updateVertices(const QPointF& center);
    double r;
};

#endif
