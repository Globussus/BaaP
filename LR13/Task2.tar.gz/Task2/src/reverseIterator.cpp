#include "reverseIterator.h"

ReverseIterator::ReverseIterator(char* ptr) : ptr_(ptr) {}

char* ReverseIterator::base() const {
    return ptr_;
}

char& ReverseIterator::operator*() const {
    return *(ptr_ - 1);
}

char* ReverseIterator::operator->() const {
    return ptr_ - 1;
}

ReverseIterator& ReverseIterator::operator++() {
    --ptr_;
    return *this;
}

ReverseIterator ReverseIterator::operator++(int) {
    ReverseIterator temp(*this);
    --ptr_;
    return temp;
}

ReverseIterator& ReverseIterator::operator--() {
    ++ptr_;
    return *this;
}

ReverseIterator ReverseIterator::operator--(int) {
    ReverseIterator temp(*this);
    ++ptr_;
    return temp;
}

ReverseIterator ReverseIterator::operator+(differenceType n) const {
    return ReverseIterator(ptr_ - n);
}

ReverseIterator ReverseIterator::operator-(differenceType n) const {
    return ReverseIterator(ptr_ + n);
}

ReverseIterator::differenceType ReverseIterator::operator-(const ReverseIterator& other) const {
    return other.ptr_ - ptr_;
}

ReverseIterator& ReverseIterator::operator+=(differenceType n) {
    ptr_ -= n;
    return *this;
}

ReverseIterator& ReverseIterator::operator-=(differenceType n) {
    ptr_ += n;
    return *this;
}

char& ReverseIterator::operator[](differenceType index) const {
    return ptr_[-index - 1];
}

bool ReverseIterator::operator==(const ReverseIterator& other) const {
    return ptr_ == other.ptr_;
}

bool ReverseIterator::operator!=(const ReverseIterator& other) const {
    return ptr_ != other.ptr_;
}

bool ReverseIterator::operator<(const ReverseIterator& other) const {
    return ptr_ > other.ptr_;
}

bool ReverseIterator::operator>(const ReverseIterator& other) const {
    return ptr_ < other.ptr_;
}

bool ReverseIterator::operator<=(const ReverseIterator& other) const {
    return ptr_ >= other.ptr_;
}

bool ReverseIterator::operator>=(const ReverseIterator& other) const {
    return ptr_ <= other.ptr_;
}