#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "polygon.h"

class Rectangle : public Polygon {
    Q_OBJECT
public:
    Rectangle(QPointF center, double width, double height, QObject *parent = nullptr);

    void setSize(double width, double height);

private:
    void updateVertices(QPointF center);
    double w, h;
};

#endif
