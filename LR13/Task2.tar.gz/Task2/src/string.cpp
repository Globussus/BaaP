#include "string.h"

String::String() : data_(nullptr), size_(0), capacity_(0) {
    reserve(15);
    data_[0] = '\0';
}

String::String(sizeType size) : data_(nullptr), size_(0), capacity_(0) {
    reserve(size > 15 ? size : 15);
    size_ = size;
    for (sizeType i = 0; i < size_; ++i) {
        data_[i] = '\0';
    }
    data_[size_] = '\0';
}

String::String(const String& other)
    : data_(nullptr), size_(other.size_), capacity_(0) {
    reserve(other.capacity_);
    for (sizeType i = 0; i < size_; ++i) {
        data_[i] = other.data_[i];
    }
    data_[size_] = '\0';
}

String::String(String&& other) noexcept
    : data_(std::move(other.data_)), size_(other.size_), capacity_(other.capacity_) {
    other.size_ = 0;
    other.capacity_ = 0;
}

String::String(std::initializer_list<char> list)
    : data_(nullptr), size_(list.size()), capacity_(0) {
    reserve(size_ > 15 ? size_ : 15);
    sizeType i = 0;
    for (auto it = list.begin(); it != list.end(); ++it, ++i) {
        data_[i] = *it;
    }
    data_[size_] = '\0';
}

String::String(const char* cStr) : data_(nullptr), size_(0), capacity_(0) {
    if (!cStr) {
        reserve(15);
        data_[0] = '\0';
        return;
    }
    sizeType len = stringLength(cStr);
    reserve(len > 15 ? len : 15);
    memoryCopy(data_.get(), cStr, len);
    size_ = len;
    data_[size_] = '\0';
}

String::~String() = default;

String& String::operator=(const char* cStr) {
    if (!cStr) {
        clear();
        return *this;
    }
    sizeType len = stringLength(cStr);
    reserve(len);
    memoryCopy(data_.get(), cStr, len);
    size_ = len;
    data_[size_] = '\0';
    return *this;
}

String& String::operator=(const String& other) {
    if (this != &other) {
        reserve(other.capacity_);
        for (sizeType i = 0; i < other.size_; ++i) {
            data_[i] = other.data_[i];
        }
        size_ = other.size_;
        data_[size_] = '\0';
    }
    return *this;
}

String& String::operator=(String&& other) noexcept {
    if (this != &other) {
        data_ = std::move(other.data_);
        size_ = other.size_;
        capacity_ = other.capacity_;
        other.size_ = 0;
        other.capacity_ = 0;
    }
    return *this;
}

String String::operator+(const String& other) const {
    String result(*this);
    result += other;
    return result;
}

String& String::operator+=(const String& other) {
    reserve(size_ + other.size_);
    memoryCopy(data_.get() + size_, other.data_.get(), other.size_);
    size_ += other.size_;
    data_[size_] = '\0';
    return *this;
}

String& String::operator+=(const char* cStr) {
    if (!cStr) {
        return *this;
    }
    sizeType len = stringLength(cStr);
    reserve(size_ + len);
    memoryCopy(data_.get() + size_, cStr, len);
    size_ += len;
    data_[size_] = '\0';
    return *this;
}

String& String::operator+=(char ch) {
    pushBack(ch);
    return *this;
}

char& String::operator[](sizeType index) {
    return data_[index];
}

const char& String::operator[](sizeType index) const {
    return data_[index];
}

char& String::at(sizeType pos) {
    if (pos >= size_) {
        throw std::out_of_range("String::at");
    }
    return data_[pos];
}

const char& String::at(sizeType pos) const {
    if (pos >= size_) {
        throw std::out_of_range("String::at");
    }
    return data_[pos];
}

char& String::front() {
    return data_[0];
}

const char& String::front() const {
    return data_[0];
}

char& String::back() {
    return data_[size_ - 1];
}

const char& String::back() const {
    return data_[size_ - 1];
}

char* String::data() {
    return data_.get();
}

const char* String::data() const {
    return data_.get();
}

const char* String::cStr() const {
    return data_.get();
}

String::sizeType String::size() const {
    return size_;
}

String::sizeType String::length() const {
    return size_;
}

String::sizeType String::capacity() const {
    return capacity_;
}

bool String::empty() const {
    return size_ == 0;
}

void String::reserve(sizeType newCapacity) {
    if (newCapacity <= capacity_) {
        return;
    }
    auto temp = std::make_unique<char[]>(newCapacity + 1);
    for (sizeType i = 0; i < size_; ++i) {
        temp[i] = data_[i];
    }
    data_ = std::move(temp);
    capacity_ = newCapacity;
}

void String::shrinkToFit() {
    if (capacity_ > size_) {
        auto temp = std::make_unique<char[]>(size_ + 1);
        for (sizeType i = 0; i < size_; ++i) {
            temp[i] = data_[i];
        }
        data_ = std::move(temp);
        capacity_ = size_;
    }
}

void String::clear() {
    size_ = 0;
    if (data_) {
        data_[0] = '\0';
    }
}

void String::pushBack(char value) {
    if (size_ + 1 >= capacity_) {
        reserve(capacity_ * 2);
    }
    data_[size_] = value;
    data_[size_ + 1] = '\0';
    ++size_;
}

void String::popBack() {
    if (size_ > 0) {
        --size_;
        data_[size_] = '\0';
    }
}

void String::resize(sizeType newSize, char value) {
    if (newSize > capacity_) {
        reserve(newSize);
    }
    if (newSize > size_) {
        for (sizeType i = size_; i < newSize; ++i) {
            data_[i] = value;
        }
    }
    size_ = newSize;
    data_[size_] = '\0';
}

Iterator String::begin() {
    return Iterator(data_.get());
}

Iterator String::end() {
    return Iterator(data_.get() + size_);
}

ReverseIterator String::rbegin() {
    return ReverseIterator(data_.get() + size_);
}

ReverseIterator String::rend() {
    return ReverseIterator(data_.get());
}

String::sizeType String::stringLength(const char* s) {
    sizeType i = 0;
    while (s && s[i] != '\0') {
        ++i;
    }
    return i;
}

void* String::memoryCopy(void* dest, const void* src, sizeType n) {
    if (!dest || !src) {
        return dest;
    }
    auto* cDest = static_cast<char*>(dest);
    const auto* cSrc = static_cast<const char*>(src);
    for (sizeType i = 0; i < n; ++i) {
        cDest[i] = cSrc[i];
    }
    return dest;
}

void* String::memoryMove(void* dest, const void* src, sizeType n) {
    if (!dest || !src || n == 0) {
        return dest;
    }
    auto* cDest = static_cast<char*>(dest);
    const auto* cSrc = static_cast<const char*>(src);
    if (cDest < cSrc) {
        for (sizeType i = 0; i < n; ++i) {
            cDest[i] = cSrc[i];
        }
    } else {
        for (sizeType i = n; i > 0; --i) {
            cDest[i - 1] = cSrc[i - 1];
        }
    }
    return dest;
}

char* String::stringCopy(char* dest, const char* src) {
    if (!dest || !src) {
        return dest;
    }
    sizeType i = 0;
    while (src[i] != '\0') {
        dest[i] = src[i];
        ++i;
    }
    dest[i] = '\0';
    return dest;
}

char* String::stringCopyN(char* dest, const char* src, sizeType n) {
    if (!dest || !src) {
        return dest;
    }
    sizeType i = 0;
    while (i < n && src[i] != '\0') {
        dest[i] = src[i];
        ++i;
    }
    while (i < n) {
        dest[i] = '\0';
        ++i;
    }
    return dest;
}

char* String::stringConcat(char* dest, const char* src) {
    if (!dest || !src) {
        return dest;
    }
    sizeType destLen = stringLength(dest);
    sizeType i = 0;
    while (src[i] != '\0') {
        dest[destLen + i] = src[i];
        ++i;
    }
    dest[destLen + i] = '\0';
    return dest;
}

char* String::stringConcatN(char* dest, const char* src, sizeType n) {
    if (!dest || !src) {
        return dest;
    }
    sizeType destLen = stringLength(dest);
    sizeType i = 0;
    while (i < n && src[i] != '\0') {
        dest[destLen + i] = src[i];
        ++i;
    }
    dest[destLen + i] = '\0';
    return dest;
}

int String::memoryCompare(const void* s1, const void* s2, sizeType n) {
    if (!s1 || !s2) {
        return 0;
    }
    const auto* lv = static_cast<const unsigned char*>(s1);
    const auto* rv = static_cast<const unsigned char*>(s2);
    for (sizeType i = 0; i < n; ++i) {
        if (lv[i] != rv[i]) {
            return (lv[i] > rv[i]) ? 1 : -1;
        }
    }
    return 0;
}

int String::stringCompare(const char* s1, const char* s2) {
    if (!s1 || !s2) {
        return 0;
    }
    sizeType i = 0;
    while (s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i]) {
        ++i;
    }
    if (s1[i] > s2[i]) {
        return 1;
    }
    if (s1[i] < s2[i]) {
        return -1;
    }
    return 0;
}

int String::stringCompareN(const char* s1, const char* s2, sizeType n) {
    if (!s1 || !s2) {
        return 0;
    }
    sizeType i = 0;
    while (i < n && s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i]) {
        ++i;
    }
    if (i == n) {
        return 0;
    }
    if (s1[i] > s2[i]) {
        return 1;
    }
    if (s1[i] < s2[i]) {
        return -1;
    }
    return 0;
}

int String::stringCollate(const char* s1, const char* s2) {
    return stringCompare(s1, s2);
}

String::sizeType String::transformString(char* dest, const char* src, sizeType n) {
    if (!dest || !src) {
        return 0;
    }
    sizeType i = 0;
    while (*src != '\0' && i < n) {
        *dest = *src;
        ++dest;
        ++src;
        ++i;
    }
    *dest = '\0';
    return i;
}

char* String::stringTokenize(char* str, const char* delimiters) {
    if (!delimiters) {
        return nullptr;
    }

    auto isDelim = [](char ch, const char* delims) -> bool {
        int i = 0;
        while (delims[i] != '\0') {
            if (delims[i] == ch) {
                return true;
            }
            ++i;
        }
        return false;
    };

    static char* backup;
    if (!str) {
        str = backup;
    }
    if (!str) {
        return nullptr;
    }

    while (isDelim(*str, delimiters)) {
        ++str;
    }
    if (*str == '\0') {
        backup = str;
        return nullptr;
    }

    char* ret = str;
    while (*str != '\0' && !isDelim(*str, delimiters)) {
        ++str;
    }
    if (*str != '\0') {
        *str = '\0';
        backup = str + 1;
    } else {
        backup = str;
    }
    return ret;
}

void* String::memorySet(void* ptr, int value, sizeType n) {
    if (!ptr) {
        return ptr;
    }
    auto* ss = static_cast<char*>(ptr);
    for (sizeType i = 0; i < n; ++i) {
        ss[i] = static_cast<char>(value);
    }
    return ptr;
}

const char* String::errorString(int errorNum) {
    static const char* errors[] = {
        "No error",
        "Operation not permitted",
        "No such file or directory",
        "No such process",
        "Interrupted system call",
        "Input/output error",
        "No such device or address",
        "Argument list too long",
        "Exec format error",
        "Bad file number",
        "No child processes",
        "Try again",
        "Out of memory",
        "Permission denied",
        "Bad address",
        "Block device required",
        "Device or resource busy",
        "File exists",
        "Cross-device link",
        "No such device",
        "Not a directory",
        "Is a directory",
        "Invalid argument",
        "File table overflow",
        "Too many open files",
        "Not a typewriter",
        "Text file busy",
        "File too large",
        "No space left on device",
        "Illegal seek",
        "Read-only file system",
        "Too many links",
        "Broken pipe",
        "Math argument out of domain of func",
        "Math result not representable"
    };

    sizeType count = sizeof(errors) / sizeof(errors[0]);
    if (errorNum >= 0 && static_cast<sizeType>(errorNum) < count) {
        return errors[errorNum];
    }
    return "Unknown error";
}