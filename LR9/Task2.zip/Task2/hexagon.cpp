#include "hexagon.h"

#include <QtMath>

Hexagon::Hexagon(const QPointF& center, double radius, QObject *parent)
    : Polygon(parent), r(radius)
{
    updateVertices(center);
}

void Hexagon::setRadius(double radius) {
    QPointF currentCenter = centerOfMass();
    r = qMax(0.0, radius);
    updateVertices(currentCenter);
}

void Hexagon::updateVertices(const QPointF& center) {
    vertices.clear();
    for (int i = 0; i < 6; ++i) {
        double angle = qDegreesToRadians(i * 60.0);
        double x = center.x() + r * qCos(angle);
        double y = center.y() + r * qSin(angle);
        vertices << QPointF(x, y);
    }

    emit shapeChanged();
}
