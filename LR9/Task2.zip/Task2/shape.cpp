#include "shape.h"
#include <QVariantAnimation>

#include <QVariantAnimation>

// Инициализация границ по умолчанию
QRectF Shape::drawingBounds = QRectF(0, 0, 800, 600);

void Shape::animateMove(const QPointF& targetPos, int durationMs) {
    QVariantAnimation* anim = new QVariantAnimation(this);
    anim->setDuration(durationMs);
    anim->setStartValue(this->centerOfMass());
    anim->setEndValue(targetPos);

    connect(anim, &QVariantAnimation::valueChanged, this, [this, anim](const QVariant& value) {
        QPointF nextPos = value.toPointF();

        if (drawingBounds.contains(nextPos)) {
            this->setCenterOfMass(nextPos);
            emit shapeChanged();
        } else {
            anim->stop();
        }
    });

    connect(anim, &QVariantAnimation::finished, anim, &QObject::deleteLater);
    anim->start();
}
