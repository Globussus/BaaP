#ifndef REVERSE_ITERATOR_H
#define REVERSE_ITERATOR_H

#include <cstddef>
#include <iterator>

class ReverseIterator {
public:
    using iteratorCategory = std::random_access_iterator_tag;
    using valueType = char;
    using differenceType = std::ptrdiff_t;
    using pointer = char*;
    using reference = char&;

    explicit ReverseIterator(char* ptr);

    char* base() const;
    char& operator*() const;
    char* operator->() const;

    ReverseIterator& operator++();
    ReverseIterator operator++(int);
    ReverseIterator& operator--();
    ReverseIterator operator--(int);

    ReverseIterator operator+(differenceType n) const;
    ReverseIterator operator-(differenceType n) const;
    differenceType operator-(const ReverseIterator& other) const;

    ReverseIterator& operator+=(differenceType n);
    ReverseIterator& operator-=(differenceType n);

    char& operator[](differenceType index) const;

    bool operator==(const ReverseIterator& other) const;
    bool operator!=(const ReverseIterator& other) const;
    bool operator<(const ReverseIterator& other) const;
    bool operator>(const ReverseIterator& other) const;
    bool operator<=(const ReverseIterator& other) const;
    bool operator>=(const ReverseIterator& other) const;

private:
    char* ptr_;
};

#endif  