#ifndef RHOMBUS_H
#define RHOMBUS_H

#include "polygon.h"

class Rhombus : public Polygon {
    Q_OBJECT
public:
    Rhombus(const QPointF& center, double d1, double d2, QObject *parent = nullptr);

    void setDiagonals(double d1, double d2);

private:
    void updateVertices(const QPointF& center);
    double diag1, diag2;
};

#endif
