#include "triangle.h"

Triangle::Triangle(const QPointF& p1, const QPointF& p2, const QPointF& p3, QObject *parent)
    : Polygon(parent)
{
    vertices.clear();
    vertices << p1 << p2 << p3;
}

void Triangle::setVertex(int index, const QPointF& pos) {
    if (index >= 0 && index < vertices.size()) {
        vertices[index] = pos;
        emit shapeChanged();
    }
}
