#ifndef SQUARE_H
#define SQUARE_H

#include "polygon.h"

class Square : public Polygon {
    Q_OBJECT
public:
    Square(const QPointF& center, double side, QObject *parent = nullptr);

    void setSide(double side);

private:
    void updateVertices(const QPointF& center);
    double s;
};

#endif
