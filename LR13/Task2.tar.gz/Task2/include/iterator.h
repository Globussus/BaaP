#ifndef ITERATOR_H
#define ITERATOR_H

#include <cstddef>
#include <iterator>

class Iterator {
public:
    using iteratorCategory = std::random_access_iterator_tag;
    using valueType = char;
    using differenceType = std::ptrdiff_t;
    using pointer = char*;
    using reference = char&;

    explicit Iterator(char* ptr);

    char* base() const;
    char& operator*() const;
    char* operator->() const;

    Iterator& operator++();
    Iterator operator++(int);
    Iterator& operator--();
    Iterator operator--(int);

    Iterator operator+(differenceType n) const;
    Iterator operator-(differenceType n) const;
    differenceType operator-(const Iterator& other) const;

    Iterator& operator+=(differenceType n);
    Iterator& operator-=(differenceType n);

    char& operator[](differenceType index) const;

    bool operator==(const Iterator& other) const;
    bool operator!=(const Iterator& other) const;
    bool operator<(const Iterator& other) const;
    bool operator>(const Iterator& other) const;
    bool operator<=(const Iterator& other) const;
    bool operator>=(const Iterator& other) const;

private:
    char* ptr_;
};

#endif 