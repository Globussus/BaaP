#include "square.h"

Square::Square(const QPointF& center, double side, QObject *parent)
    : Polygon(parent), s(side)
{
    updateVertices(center);
}

void Square::setSide(double side) {
    QPointF currentCenter = centerOfMass();
    s = qMax(0.0, side);
    updateVertices(currentCenter);
}

void Square::updateVertices(const QPointF& center) {
    double half = s / 2.0;

    vertices.clear();

    vertices << QPointF(center.x() - half, center.y() - half); // Лево-Верх
    vertices << QPointF(center.x() + half, center.y() - half); // Право-Верх
    vertices << QPointF(center.x() + half, center.y() + half); // Право-Низ
    vertices << QPointF(center.x() - half, center.y() + half); // Лево-Низ

    emit shapeChanged();
}
