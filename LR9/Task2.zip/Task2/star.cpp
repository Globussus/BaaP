#include "star.h"
#include <QtMath>

Star::Star(const QPointF& center, int rays, double outerR, double innerR, QObject *parent)
    : Polygon(parent), numRays(rays), rOuter(outerR), rInner(innerR)
{
    updateVertices(center);
}

void Star::setParameters(int rays, double outerR, double innerR) {
    QPointF currentCenter = centerOfMass();
    numRays = (rays == 5 || rays == 6 || rays == 8) ? rays : 5;
    rOuter = qMax(0.0, outerR);
    rInner = qMax(0.0, innerR);

    updateVertices(currentCenter);
}

void Star::updateVertices(const QPointF& center) {
    vertices.clear();
    int totalPoints = numRays * 2;
    double angleStep = M_PI / numRays;

    for (int i = 0; i < totalPoints; ++i) {
        double currentR = (i % 2 == 0) ? rOuter : rInner;
        double angle = i * angleStep - M_PI_2;

        double x = center.x() + currentR * qCos(angle);
        double y = center.y() + currentR * qSin(angle);
        vertices << QPointF(x, y);
    }

    emit shapeChanged();
}
