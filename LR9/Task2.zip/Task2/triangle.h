#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "polygon.h"

class Triangle : public Polygon {
    Q_OBJECT
public:
    Triangle(const QPointF& p1, const QPointF& p2, const QPointF& p3, QObject *parent = nullptr);

    void setVertex(int index, const QPointF& pos);
};

#endif
