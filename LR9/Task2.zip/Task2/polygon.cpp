#include "polygon.h"
#include <QtMath>
#include <QPolygonF>

void Polygon::setVertices(const QVector<QPointF>& newVertices) {
    vertices = newVertices;
    emit shapeChanged();
}

double Polygon::area() const {
    double a = 0.0;
    int n = vertices.size();
    if (n < 3) return 0.0;
    for (int i = 0; i < n; i++) {
        a += (vertices[i].x() * vertices[(i + 1) % n].y() - vertices[(i + 1) % n].x() * vertices[i].y());
    }
    return qAbs(a) / 2.0;
}

double Polygon::perimeter() const {
    double p = 0.0;
    for (int i = 0; i < vertices.size(); i++) {
        QPointF diff = vertices[i] - vertices[(i + 1) % vertices.size()];
        p += qSqrt(diff.x() * diff.x() + diff.y() * diff.y());
    }
    return p;
}

QPointF Polygon::centerOfMass() const {
    double cx = 0, cy = 0;
    double a = 0;
    int n = vertices.size();
    if (n < 3) return QPointF(0, 0);

    for (int i = 0; i < n; i++) {
        double factor = (vertices[i].x() * vertices[(i + 1) % n].y() - vertices[(i + 1) % n].x() * vertices[i].y());
        cx += (vertices[i].x() + vertices[(i + 1) % n].x()) * factor;
        cy += (vertices[i].y() + vertices[(i + 1) % n].y()) * factor;
        a += factor;
    }
    a *= 0.5;
    if (qFuzzyIsNull(a)) return vertices[0];
    return QPointF(cx / (6.0 * a), cy / (6.0 * a));
}

void Polygon::setCenterOfMass(const QPointF& newCenter) {
    move(newCenter - centerOfMass());
}

void Polygon::move(const QPointF& delta) {
    for (QPointF &v : vertices) v += delta;
    emit shapeChanged();
}

void Polygon::rotate(double angleDegrees, const QPointF& pivot) {
    double rad = qDegreesToRadians(angleDegrees);
    double cosA = qCos(rad);
    double sinA = qSin(rad);

    for (QPointF &v : vertices) {
        double x = v.x() - pivot.x();
        double y = v.y() - pivot.y();
        v.setX(pivot.x() + x * cosA - y * sinA);
        v.setY(pivot.y() + x * sinA + y * cosA);
    }
    emit shapeChanged();
}

void Polygon::scale(double factor, const QPointF& pivot) {
    for (QPointF &v : vertices) {
        v = pivot + (v - pivot) * factor;
    }
    emit shapeChanged();
}

void Polygon::draw(QPainter* painter) const {
    painter->drawPolygon(QPolygonF(vertices));
}

bool Polygon::contains(const QPointF& point) const {
    return QPolygonF(vertices).containsPoint(point, Qt::OddEvenFill);
}
