#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QDoubleSpinBox>
#include <QLabel>
#include "canvas.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void createTriangle();
    void createCircle();
    void createRectangle();
    void createSquare();
    void createStar();
    void createHexagon();

    void animateSelected();

private:
    Canvas *canvas;

    QDoubleSpinBox *scaleSpin;
    QDoubleSpinBox *rotateSpin;

    void setupUi();
};

#endif
