#include "mainwindow.h"
#include "triangle.h"
#include "circle.h"
#include "rectangle.h"
#include "square.h"
#include "star.h"
#include "hexagon.h"
#include <QHBoxLayout>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    setupUi();
    setWindowTitle("Геометрический редактор");
    resize(1000, 700);
}

MainWindow::~MainWindow() {}

void MainWindow::setupUi() {
    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);

    canvas = new Canvas(this);
    mainLayout->addWidget(canvas, 1);

    QVBoxLayout *sidePanel = new QVBoxLayout();
    QGroupBox *createGroup = new QGroupBox("Создать фигуру", this);
    QVBoxLayout *btnLayout = new QVBoxLayout(createGroup);

    QPushButton *btnTriangle = new QPushButton("Треугольник");
    QPushButton *btnCircle = new QPushButton("Круг");
    QPushButton *btnRect = new QPushButton("Прямоугольник");
    QPushButton *btnSquare = new QPushButton("Квадрат");
    QPushButton *btnStar = new QPushButton("Звезда (5 лучей)");
    QPushButton *btnHex = new QPushButton("Шестиугольник");

    btnLayout->addWidget(btnTriangle);
    btnLayout->addWidget(btnCircle);
    btnLayout->addWidget(btnRect);
    btnLayout->addWidget(btnSquare);
    btnLayout->addWidget(btnStar);
    btnLayout->addWidget(btnHex);

    sidePanel->addWidget(createGroup);

    QGroupBox *animGroup = new QGroupBox("Анимация и тесты", this);
    QVBoxLayout *animLayout = new QVBoxLayout(animGroup);

    QPushButton *btnAnimate = new QPushButton("Плавный сдвиг в центр");
    animLayout->addWidget(btnAnimate);

    sidePanel->addWidget(animGroup);
    sidePanel->addStretch();

    mainLayout->addLayout(sidePanel);

    connect(btnTriangle, &QPushButton::clicked, this, &MainWindow::createTriangle);
    connect(btnCircle, &QPushButton::clicked, this, &MainWindow::createCircle);
    connect(btnRect, &QPushButton::clicked, this, &MainWindow::createRectangle);
    connect(btnSquare, &QPushButton::clicked, this, &MainWindow::createSquare);
    connect(btnStar, &QPushButton::clicked, this, &MainWindow::createStar);
    connect(btnHex, &QPushButton::clicked, this, &MainWindow::createHexagon);
    connect(btnAnimate, &QPushButton::clicked, this, &MainWindow::animateSelected);
}

void MainWindow::createTriangle() {
    QPointF c = canvas->rect().center();
    canvas->addShape(new Triangle(c + QPointF(0,-50), c + QPointF(50,50), c + QPointF(-50,50)));
}

void MainWindow::createCircle() {
    canvas->addShape(new Circle(canvas->rect().center(), 50.0));
}

void MainWindow::createRectangle() {
    canvas->addShape(new Rectangle(canvas->rect().center(), 120.0, 80.0));
}

void MainWindow::createSquare() {
    canvas->addShape(new Square(canvas->rect().center(), 80.0));
}

void MainWindow::createStar() {
    canvas->addShape(new Star(canvas->rect().center(), 5, 60.0, 25.0));
}

void MainWindow::createHexagon() {
    canvas->addShape(new Hexagon(canvas->rect().center(), 55.0));
}

void MainWindow::animateSelected() {
    QPointF target = canvas->rect().center();
}
