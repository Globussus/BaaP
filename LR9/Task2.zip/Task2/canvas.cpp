#include "canvas.h"
#include <QPainter>

Canvas::Canvas(QWidget *parent)
    : QWidget(parent), selectedShape(nullptr), isDragging(false)
{
    setMouseTracking(true);
    Shape::setBounds(rect());
}

Canvas::~Canvas() {
    clear();
}

void Canvas::addShape(Shape* shape) {
    if (!shape) return;
    shapes.append(shape);
    connect(shape, &Shape::shapeChanged, this, QOverload<>::of(&Canvas::update));
    update();
}

void Canvas::clear() {
    for (Shape* s : shapes) {
        delete s;
    }
    shapes.clear();
    selectedShape = nullptr;
    update();
}

void Canvas::paintEvent(QPaintEvent *event) {
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    painter.fillRect(rect(), Qt::white);

    for (const Shape* shape : shapes) {
        if (shape == selectedShape) {
            painter.setPen(QPen(Qt::blue, 2, Qt::DashLine));
            painter.setBrush(QBrush(QColor(0, 120, 215, 40)));
        } else {
            painter.setPen(QPen(Qt::black, 1));
            painter.setBrush(QBrush(QColor(200, 200, 200, 80)));
        }
        shape->draw(&painter);
    }
}

void Canvas::mousePressEvent(QMouseEvent *event) {
    selectedShape = nullptr;
    for (int i = shapes.size() - 1; i >= 0; --i) {
        if (shapes[i]->contains(event->position())) {
            selectedShape = shapes[i];
            isDragging = true;
            lastMousePos = event->position();
            break;
        }
    }
    update();
}

void Canvas::mouseMoveEvent(QMouseEvent *event) {
    if (isDragging && selectedShape) {
        QPointF currentPos = event->position();
        QPointF delta = currentPos - lastMousePos;

        QPointF nextCenter = selectedShape->centerOfMass() + delta;

        if (rect().contains(nextCenter.toPoint())) {
            selectedShape->move(delta);
            lastMousePos = currentPos;
        }
    }
}

void Canvas::mouseReleaseEvent(QMouseEvent *event) {
    isDragging = false;
}

void Canvas::resizeEvent(QResizeEvent *event) {
    Shape::setBounds(rect());
    QWidget::resizeEvent(event);
}
