#include "rectangle.h"

Rectangle::Rectangle(QPointF center, double width, double height, QObject *parent)
    : Polygon(parent), w(width), h(height)
{
    updateVertices(center);
}

void Rectangle::setSize(double width, double height) {
    QPointF currentCenter = centerOfMass();
    w = width;
    h = height;
    updateVertices(currentCenter);
}

void Rectangle::updateVertices(QPointF center) {
    double hw = w / 2.0;
    double hh = h / 2.0;

    vertices.clear();

    vertices << QPointF(center.x() - hw, center.y() - hh); // Л-В
    vertices << QPointF(center.x() + hw, center.y() - hh); // П-В
    vertices << QPointF(center.x() + hw, center.y() + hh); // П-Н
    vertices << QPointF(center.x() - hw, center.y() + hh); // Л-Н

    emit shapeChanged();
}
