#ifndef OCTAGON_H
#define OCTAGON_H

#include "polygon.h"

class Octagon : public Polygon {
    Q_OBJECT
public:
    Octagon(const QPointF& center, double radius, QObject *parent = nullptr);

    void setRadius(double radius);

private:
    void updateVertices(const QPointF& center);
    double r;
};

#endif // OCTAGON_H
