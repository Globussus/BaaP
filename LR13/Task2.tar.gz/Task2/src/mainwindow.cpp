#include "mainwindow.h"

#include <QVBoxLayout>

#include "dialog.h"

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent),
      string(""),
      stringButton(new QPushButton()),
      textEdit(new QTextEdit()) {
    setWindowTitle("Task 2");
    setStyleSheet(
        "background-color: #181818;"
        "color: white;");

    stringButton->setText("String");

    textEdit->setStyleSheet(
        "background-color: #1f1f1f;"
        "border-color: #2b2b2b;"
        "border-radius: 10px;"
        "padding: 5px;"
        "font-size: 30px;");
    textEdit->setReadOnly(true);

    auto* vLayout = new QVBoxLayout();
    vLayout->addWidget(stringButton);
    vLayout->addWidget(textEdit);
    centralWidget()->setLayout(vLayout);

    connect(stringButton, &QPushButton::clicked, this, &MainWindow::stringClicked);

    updateDisplay();
}

MainWindow::~MainWindow() {}

void MainWindow::updateDisplay() {
    textEdit->setText(QString(string.cStr()));
}

void MainWindow::stringClicked() {
    auto* dialog = new Dialog(this, &string);
    dialog->exec();
    delete dialog;
}