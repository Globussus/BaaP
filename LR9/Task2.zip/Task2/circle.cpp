#include "circle.h"

Circle::Circle(QPointF center, double radius, QObject *parent)
    : Shape(parent), center(center), r(radius) {}

double Circle::area() const {
    return M_PI * r * r;
}

double Circle::perimeter() const {
    return 2 * M_PI * r;
}

QPointF Circle::centerOfMass() const {
    return center;
}

void Circle::setCenterOfMass(const QPointF& newCenter) {
    center = newCenter;
    emit shapeChanged();
}

void Circle::move(const QPointF& delta) {
    center += delta;
    emit shapeChanged();
}

void Circle::rotate(double angleDegrees, const QPointF& pivot) {
    if (center == pivot) return;

    double rad = qDegreesToRadians(angleDegrees);
    double cosA = qCos(rad);
    double sinA = qSin(rad);

    double dx = center.x() - pivot.x();
    double dy = center.y() - pivot.y();

    center.setX(pivot.x() + dx * cosA - dy * sinA);
    center.setY(pivot.y() + dx * sinA + dy * cosA);
    emit shapeChanged();
}

void Circle::scale(double factor, const QPointF& pivot) {
    r *= qAbs(factor);
    center = pivot + (center - pivot) * factor;
    emit shapeChanged();
}

void Circle::draw(QPainter* painter) const {
    painter->drawEllipse(center, r, r);
}

bool Circle::contains(const QPointF& point) const {
    QPointF diff = point - center;
    return (diff.x() * diff.x() + diff.y() * diff.y()) <= (r * r);
}

void Circle::setRadius(double newR) {
    r = qMax(0.0, newR);
    emit shapeChanged();
}
