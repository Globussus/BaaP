#ifndef POLYGON_H
#define POLYGON_H

#include "shape.h"
#include <QVector>
#include <QVector>
#include <QPointF>

class Polygon : public Shape {
    Q_OBJECT
public:
    explicit Polygon(QObject *parent = nullptr) : Shape(parent) {}

    double area() const override;
    double perimeter() const override;
    QPointF centerOfMass() const override;

    void move(const QPointF& delta) override;
    void rotate(double angleDegrees, const QPointF& pivot) override;
    void scale(double factor, const QPointF& pivot) override;

    void setCenterOfMass(const QPointF& newCenter) override;

    void draw(QPainter* painter) const override;
    bool contains(const QPointF& point) const override;

    const QVector<QPointF>& getVertices() const { return vertices; }
    void setVertices(const QVector<QPointF>& newVertices);

protected:
    QVector<QPointF> vertices;
};
#endif
