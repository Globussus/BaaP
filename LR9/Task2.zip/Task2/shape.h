#ifndef SHAPE_H
#define SHAPE_H

#include <QObject>
#include <QPainter>
#include <QPointF>
#include <QRectF>

class Shape : public QObject {
    Q_OBJECT
public:
    explicit Shape(QObject *parent = nullptr) : QObject(parent) {}
    virtual ~Shape() = default;

    virtual double area() const = 0;
    virtual double perimeter() const = 0;
    virtual QPointF centerOfMass() const = 0;
    virtual void setCenterOfMass(const QPointF& newCenter) = 0;

    virtual void move(const QPointF& delta) = 0;
    virtual void rotate(double angleDegrees, const QPointF& pivot) = 0;
    virtual void scale(double factor, const QPointF& pivot) = 0;

    virtual void draw(QPainter* painter) const = 0;
    virtual bool contains(const QPointF& point) const = 0;

    void animateMove(const QPointF& targetPos, int durationMs);

    static void setBounds(const QRectF& rect) { drawingBounds = rect; }

signals:
    void shapeChanged();

protected:
    static QRectF drawingBounds;
};

#endif
